using System;
using System.Collections.Generic; 
using SemillasC;
namespace SemillasC.SemillaComestible{
   public class SemillasComestibles:Semillas{
       #region Properties
       public List<Semillas> semillasParaConsumo = new List<Semillas>();
       
       public int semillasComestibles(int cant){
           cantSemillas = cant;
           return cant;
       }
       #endregion Properties
   }
}