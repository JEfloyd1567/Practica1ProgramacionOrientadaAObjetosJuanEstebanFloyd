using System;
using SemillasC;
using SemillasC.SemillaNoComestible;
using SemillasC.SemillaComestible;

namespace BodegaDeSemilla{
   public class BodegaDeSemillas{
       #region Properties
       public int cantSemillasComestibles = 0;
       public int cantSemillasNoComestibles = 0;
       #endregion Properties
       #region methods
        public bool agregarSemillasComestibles( SemillasComestibles semilla ){
           cantSemillasComestibles = cantSemillasComestibles + 1; 
           return true;
        }
        public bool agregarSemillasNoComestibles( SemillasNoComestibles semilla ){
           cantSemillasNoComestibles = cantSemillasNoComestibles + 1; 
           return true;
        }
       #endregion methods
   }
}