﻿using System;
using SemillasC;
using SemillasC.SemillaNoComestible;
using SemillasC.SemillaComestible;
using System.Collections.Generic;
using BodegaDeSemilla;
using CentroDeControlG;
namespace granjaTarea
{
    class Program
    {
        static void Main(string[] args)
        {
            SemillasComestibles naranja = new SemillasComestibles();
            CentroDeControl centroNaranja = new CentroDeControl();
            centroNaranja.plantarSemillaComestible(naranja);
            centroNaranja.darTecho();
            centroNaranja.realizarDiagnostico();
            centroNaranja.transportarSemillasComestibles(naranja);
            centroNaranja.recogerSemillaComestibles(naranja);
            centroNaranja.recogerTecho();
        }
    }
}
