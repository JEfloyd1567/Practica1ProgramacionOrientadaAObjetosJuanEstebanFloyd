using System;
using SemillasC;
using SemillasC.SemillaNoComestible;
using SemillasC.SemillaComestible;
using System.Collections.Generic;
using BodegaDeSemilla;

namespace CentroDeControlG{
   public class CentroDeControl{
       #region Properties
       public bool techo = false;
       public bool diagnotiscoDelSistema = true;
       public bool seguridadDelSistema = true;
       public List<Semillas> despacho = new List<Semillas>();
       public bool diagnosticoPlantas = true;
       public int cantPlantasRegadas = 0;
       public int cantSemillasListas = 0;
       public int cantSemillasPlantadasComestibles = 0;
       public int cantSemillasPlantadasNoComestibles = 0;
       public List<Semillas> semillasListas = new List<Semillas>();

       #endregion Properties

        #region methods
        public bool darTecho(){
           if( techo == false ){
               techo = true;
           }
           return techo;
        }
        public bool recogerTecho(){
            if( techo == true ){
                techo = false;
            }
            return techo;
        }
        public bool realizarDiagnostico(){
            if( diagnotiscoDelSistema == true){
                Console.WriteLine("El sistema esta funcionando correctamente");
            }
            return true;
        }

        public bool plantarSemillaComestible(SemillasComestibles planta){
            bool estado;
            SemillasComestibles x = new SemillasComestibles();
            planta.cantSemillas =  planta.cantSemillas + 1;
            x.semillasParaConsumo.Add(planta);
            cantSemillasPlantadasComestibles = cantSemillasPlantadasComestibles + 1; 
            estado = true;
            return estado;
        }
        public bool plantarSemillaNoComestible(SemillasNoComestibles planta){
            bool estado;
            SemillasNoComestibles x = new SemillasNoComestibles();
            planta.cantSemillas =  planta.cantSemillas + 1;
            x.semillasNoConsumo.Add(planta);
            cantSemillasPlantadasNoComestibles = cantSemillasPlantadasNoComestibles + 1; 
            estado = true;
            return estado;
        }
        public bool recogerSemillaComestibles(SemillasComestibles planta){
            if(planta.semillasParaConsumo.Contains(planta)){
                planta.semillasParaConsumo.Remove(planta);
            }
            cantSemillasListas = cantSemillasListas + 1;
            return true;
        }

        public bool recogerSemillaNoComestibles(SemillasNoComestibles planta){
            if(planta.semillasNoConsumo.Contains(planta)){
                planta.semillasNoConsumo.Remove(planta);
            }
            cantSemillasListas = cantSemillasListas + 1;
            return true;
        }
        
  

        public bool transportarSemillasComestibles(SemillasComestibles plantas){
            if(plantas.semillasParaConsumo.Contains(plantas)){
                despacho.Add(plantas);
            }
            return true;
        }       
        public bool transsportarSemillasNoComestibles(SemillasNoComestibles plantas){
            SemillasNoComestibles x = new SemillasNoComestibles();
                if(plantas.semillasNoConsumo.Contains(plantas)){
                    despacho.Add(plantas);
                }  
            return true;         
        }       
 
        public bool llevarSemillasComestiblesAlmacen(SemillasComestibles plantas){
            BodegaDeSemillas x = new BodegaDeSemillas();
            if(despacho.Contains(plantas)){
                despacho.Remove(plantas);
            }
            x.agregarSemillasComestibles(plantas);
            return true;
        }
        public bool llevarSemillasNoComestiblesAlmacen(SemillasNoComestibles plantas){
            BodegaDeSemillas x = new BodegaDeSemillas();
            if(despacho.Contains(plantas)){
                despacho.Remove(plantas);
            }
            x.agregarSemillasNoComestibles(plantas);     
            return true;      
        }

       #endregion methods
   }
   
}