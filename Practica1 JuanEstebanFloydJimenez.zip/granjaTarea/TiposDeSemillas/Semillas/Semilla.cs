using System;
using System.Collections.Generic;

namespace SemillasC{
   public class Semillas{
       #region Properties
       public int cantSemillas;

       #endregion Properties
   }
}
