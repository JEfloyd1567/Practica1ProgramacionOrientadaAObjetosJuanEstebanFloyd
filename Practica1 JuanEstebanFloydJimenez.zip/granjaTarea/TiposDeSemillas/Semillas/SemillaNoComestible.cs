using System;
using System.Collections.Generic;
using SemillasC;
namespace SemillasC.SemillaNoComestible{
   public class SemillasNoComestibles:Semillas{
       #region Properties
       public List<Semillas> semillasNoConsumo = new List<Semillas>();

       public int semillasNoComestibles(int cant){
           cantSemillas = cant;
           return cant;
       }
       #endregion Properties
   }
}
